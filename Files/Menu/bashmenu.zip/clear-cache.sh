#!/bin/sh
# Copyright By AHMAD FAUZAN
clear
echo ""
echo "========================================================================="
echo "                 Clear Cache, Restart SSH & Dropbear"
echo "========================================================================="
echo ""
free && sync && echo 3 > /proc/sys/vm/drop_caches && echo "" && free
echo ""
service ssh restart
echo ""
service dropbear restart
echo ""
echo "========================================================================="
echo "                      [ Scipt By Ahmad Fauzan ]"
echo "========================================================================="
echo ""